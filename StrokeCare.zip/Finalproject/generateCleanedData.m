%% generateCleanedData.m

% This function filters and reshapes the GBD dataset 
% (downloaded specifically for stroke in China, 2021)
% to generate a clean, structured CSV file for use in the StrokeCare project.

data = readtable('IHME-GBD_2021_DATA-a48e9461-1.csv');

% Filter rows
% Keep only China + Stroke + DALYs + Rate + Year 2021
chinaData = strcmp(data.location_name, 'China');
strokeData = strcmp(data.cause_name, 'Stroke');
dalyData = strcmp(data.measure_name, 'DALYs (Disability-Adjusted Life Years)');
rateData = strcmp(data.metric_name, 'Rate');
year2021 = data.year == 2021;

filtered = data(chinaData & strokeData & dalyData & rateData & year2021, :);

% Get unique age groups
ageGroups = unique(filtered.age_name);

% Create empty vectors
maleVals = zeros(length(ageGroups), 1);
femaleVals = zeros(length(ageGroups), 1);

% Extract values by sex
for i = 1:length(ageGroups)
    ageNow = ageGroups{i};

    maleRow = strcmp(filtered.age_name, ageNow) & strcmp(filtered.sex_name, 'Male');
    femaleRow = strcmp(filtered.age_name, ageNow) & strcmp(filtered.sex_name, 'Female');

    maleVals(i) = filtered.val(maleRow);
    femaleVals(i) = filtered.val(femaleRow);
end

% Create final table
T = table(ageGroups, maleVals, femaleVals, ...
    'VariableNames', {'age_name', 'Male', 'Female'});

% Sort by age manually
ageOrder = {'<5 years','5-9 years','10-14 years','15-19 years','20-24 years',...
    '25-29 years','30-34 years','35-39 years','40-44 years','45-49 years',...
    '50-54 years','55-59 years','60-64 years','65-69 years','70-74 years',...
    '75-79 years','80-84 years','85-89 years','90-94 years','95+ years'};

[~, sortIndex] = ismember(T.age_name, ageOrder);
T = T(sortIndex > 0, :);
T = T(sortrows(sortIndex(sortIndex > 0)), :);

% Step 8: Save final cleaned form
writetable(T, 'chinastrokeDaly2021BySexCleaned.csv');
fprintf('Cleaned data saved as chinastrokeDaly2021BySexCleaned.csv\n');