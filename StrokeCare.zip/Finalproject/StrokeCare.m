function StrokeCare
% StrokeCare Final Project
% Human-centered stroke risk assessment tool with multi-user interaction

% Project Manual

% This program is a function. To run it, make sure the following two files
% are in the same folder:
%   - StrokeCare.m
%   - chinastrokeDaly2021BySexCleaned.csv

% The program will ask for user information:
%   - Name
%   - Age
%   - Gender (male/female)
%   - Systolic blood pressure (SBP)
%   - BMI
%   - Smoking status (yes/no)
% All user reports are saved as individual .txt files.
% All users are saved into userDataAll.mat as a struct cell array.
% You can load and view them later using:
%   >> load('userDataAll.mat');
%   >> userList
clear; clc; close all;
tic
% Load cleaned GBD stroke data
data = readtable('chinastrokeDaly2021BySexCleaned.csv');
ages = data.age_name;
maleVals = data.Male;
femaleVals = data.Female;

userCount = 0;

while true
    clc;
    userCount = userCount + 1;

    fprintf('Welcome to StrokeCare - Stroke Risk Evaluation System\n\n');

    % User input
    userName = input('Enter user name: ', 's');
    age = input('Enter your age: ');
    gender = lower(input('Gender (male/female): ', 's'));
    sbp = input('Systolic blood pressure (SBP): ');
    bmi = input('BMI: ');
    smoking = input('Do you smoke? (yes/no): ', 's');

    % Match Age Group
    ageGroups = {'<5 years','5-9 years','10-14 years','15-19 years','20-24 years','25-29 years',...
        '30-34 years','35-39 years','40-44 years','45-49 years','50-54 years','55-59 years',...
        '60-64 years','65-69 years','70-74 years','75-79 years','80-84 years','85-89 years',...
        '90-94 years','95+ years'};
    idx = findAgeGroup(age, ageGroups);

    if isempty(idx)
        fprintf('Age not supported in this dataset.\n');
        continue;
    end

    userAgeGroup = ageGroups{idx};

    % Extract DALY
    if strcmp(gender, 'male')
        daly = maleVals(idx);
    elseif strcmp(gender, 'female')
        daly = femaleVals(idx);
    else
        fprintf('Invalid gender.\n');
        continue;
    end

    % Analyze & Classify
    if daly > 2500
        riskLevel = 'Very High';
    elseif daly > 1500
        riskLevel = 'High';
    elseif daly > 800
        riskLevel = 'Moderate';
    else
        riskLevel = 'Low';
    end

    % Display results on screen
    fprintf('\nUser: %s\nAge group: %s\nGender: %s\n', userName, userAgeGroup, gender);
    fprintf('Stroke DALY per 100,000: %.2f\n', daly);
    fprintf('Overall stroke risk level: %s\n', riskLevel);
    fprintf('\nHealth suggestions:\n');

    % Save text report
    fileName = sprintf('healthReport_%s_%d.txt', lower(userName), userCount);
    fid = fopen(fileName, 'w');
    fprintf(fid, '--- StrokeCare Report ---\n');
    fprintf(fid, 'User: %s\n', userName);
    fprintf(fid, 'Age: %d (%s)\n', age, userAgeGroup);
    fprintf(fid, 'Gender: %s\n', gender);
    fprintf(fid, 'DALY per 100,000: %.2f\n', daly);
    fprintf(fid, 'Stroke Risk Level: %s\n\n', riskLevel);
    fprintf(fid, 'Health Recommendations:\n');

    % New: switch-case for assessment tone
    switch riskLevel
        case "Very High"
            tone = "URGENT!";
        case "High"
            tone = "Take action soon.";
        case "Moderate"
            tone = "Monitor and improve.";
        case "Low"
            tone = "Keep up the healthy habits.";
        otherwise
            tone = "No risk data.";
    end
    fprintf(fid, 'Assessment tone: %s\n', tone);
    fprintf('Assessment tone: %s\n', tone);

    if sbp >= 140
        fprintf(fid, 'High blood pressure detected. You may consider regular monitoring and reducing salt intake.\n');
        fprintf('High blood pressure detected. You may consider regular monitoring and reducing salt intake.\n');
    end

    if bmi >= 25
        fprintf(fid, 'You are overweight. Regular physical activity and dietary control are advised.\n');
        fprintf('You are overweight. Regular physical activity and dietary control are advised.\n');
    elseif bmi < 18.5
        fprintf(fid, 'You are underweight. Nutritional support may be needed.\n');
        fprintf('You are underweight. Nutritional support may be needed.\n');
    end

    if strcmpi(smoking, 'yes')
        fprintf(fid, 'Smoking increases stroke risk. Quitting is the best option.\n');
        fprintf('Smoking increases stroke risk. Quitting is the best option.\n');
    end

    fclose(fid);
    fprintf('\nPersonal report saved to file: %s\n', fileName);

    % New: store user info in .mat file
    if exist('userDataAll.mat', 'file')
        load('userDataAll.mat', 'userList');
    else
        userList = {};
    end
    userInfoStruct = struct('Name', userName, 'Age', age, 'AgeGroup', userAgeGroup, ...
        'Gender', gender, 'DALY', daly, 'SBP', sbp, 'BMI', bmi, ...
        'Smoking', smoking, 'RiskLevel', riskLevel);
    userList{end+1} = userInfoStruct;
    save('userDataAll.mat', 'userList');

    % Plot chart
    figure;
    bar([maleVals femaleVals]);
    xticks(1:length(ages));
    xticklabels(ages);
    xtickangle(45);
    ylabel('DALY per 100,000');
    legend('Male','Female');
    title('Stroke Burden by Age and Sex (China, 2021)');
    hold on;
    bar(idx, [maleVals(idx) femaleVals(idx)], 'r', 'DisplayName', '');
    text(idx, max([maleVals(idx), femaleVals(idx)]) + 50, userName, ...
        'Color','red','HorizontalAlignment','center');
    drawnow;

    % Ask to continue
    more = input('\nWould you like to enter another user? (yes/no): ', 's');
    if strcmpi(more, 'no')
        break;
    end
end

fprintf('\nThank you for using StrokeCare!\n');
toc
end

% Helper function
function idx = findAgeGroup(age, ageGroups)
    edges = [0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 200];
    idx = find(age >= edges(1:end-1) & age < edges(2:end));
    if isempty(idx) || idx > length(ageGroups)
        idx = [];
    end
end