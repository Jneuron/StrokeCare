% LaunchStrokeCare.m
% Unified launcher for data cleaning + program experience

clc;
disp("Welcome to the StrokeCare System.");
pause(2);
% Step 1: Ask to clean data
startClean = input("Shall I help you prepare the data first? (yes/no): ", 's');

if strcmp(startClean, 'yes')
    disp("Starting data preparation...");
    generateCleanedData;   % make sure this file is in the folder
    disp("Data preparation completed.");
else
    disp("Okay. Have a Good Day!");
    return;
end

% Step 2: Introduction and confirmation
disp("Now the data is ready.");
disp("This program evaluates stroke risk using DALY data from GBD 2021 for China.");
proceed = lower(input("Would you like to try the program now? (yes/no): ", 's'));

if strcmp(proceed, 'yes')
    StrokeCare;
else
    disp("No problem. You can start it anytime by running 'StrokeCare' again.");
end